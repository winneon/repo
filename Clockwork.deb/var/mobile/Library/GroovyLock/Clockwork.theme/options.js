// true = 12 hours (i.e. 16:00)
// false = 24 hours (i.e. 4:00 PM)
var hours12format = false;

// true = show time in text format (i.e. twelve.o'clock)
// false = show time in number format (i.e. 12:00)
var textFormat = true;