// 24 hour time. true = 24 hours, false = 12 hours.
var hours24 = false;